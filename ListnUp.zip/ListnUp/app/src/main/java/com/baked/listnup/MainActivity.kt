package com.baked.listnup

import android.os.Bundle
import android.widget.TextView
import android.util.Log
import com.google.android.material.snackbar.Snackbar
import java.io.IOException
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.Callback
import okhttp3.Call
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*

class MainActivity : AppCompatActivity() {
    val homeTitles: ArrayList<String> = ArrayList()
//    var homeList: RecyclerView? = null
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        addTitles()
        home_list.layoutManager = LinearLayoutManager(this)
        home_list.adapter = HomeAdapter(homeTitles, this)

        fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show()
//
//            Toast.makeText(this@MainActivity, "FAB is clicked...", Toast.LENGTH_LONG).show()

//            var responseText: String
//            val responseText = "Yo!"
//            textView.text = responseText//.toString()
run()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }


    fun run(){
        val request = Request.Builder()
            .url("http://10.0.0.164:80/index.php")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response){
                response.use {
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val resp = response.body!!.string()
//                    for ((name, value) in response.headers) {
//                        println("$name: $value")
//                    }
//                    resp = response.body!!.string()
//                    println(resp)
//                    println(response.body!!.string())
//                    textView?.text ="test" //resp
                    this@MainActivity.runOnUiThread(Runnable {
                        //textView?.text = resp
                    })
                }
            }
        })
    }

    fun addTitles() {
        homeTitles.add("dog")
        homeTitles.add("cat")
        homeTitles.add("owl")
        homeTitles.add("cheetah")
        homeTitles.add("raccoon")
        homeTitles.add("bird")
        homeTitles.add("snake")
        homeTitles.add("lizard")
        homeTitles.add("hamster")
        homeTitles.add("bear")
        homeTitles.add("lion")
        homeTitles.add("tiger")
        homeTitles.add("horse")
        homeTitles.add("frog")
        homeTitles.add("fish")
        homeTitles.add("shark")
        homeTitles.add("turtle")
        homeTitles.add("elephant")
        homeTitles.add("cow")
        homeTitles.add("beaver")
        homeTitles.add("bison")
        homeTitles.add("porcupine")
        homeTitles.add("rat")
        homeTitles.add("mouse")
        homeTitles.add("goose")
        homeTitles.add("deer")
        homeTitles.add("fox")
        homeTitles.add("moose")
        homeTitles.add("buffalo")
        homeTitles.add("monkey")
        homeTitles.add("penguin")
        homeTitles.add("parrot")
    }
}
